# -*- coding: utf-8 -*-
"""
Tokenizer module for WH40K annotation processing
""" 