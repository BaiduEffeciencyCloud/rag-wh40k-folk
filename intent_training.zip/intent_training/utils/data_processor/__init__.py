# -*- coding: utf-8 -*-
"""
Data processor module for annotation processing
""" 